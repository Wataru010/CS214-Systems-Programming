echo foo bar > baz
echo foo > baz bar
echo > baz foo bar
sort < foo > bar
sort > bar < foo
echo foo > bar | cat
echo foo > bar > baz 
cat < foo < bar 
echo foo | cat < bar 
ec*o foo
pwd > some_file
pwd | ./revline
touch foo | cd some_dir
cd some_dir | pwd
touch foo | exit
