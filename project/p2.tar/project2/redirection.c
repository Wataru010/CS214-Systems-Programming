#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){

    if(argc == 1){
        printf("%s\n", argv[1]);
    }else{
        for(int index = 0; index < argc; index++){
            printf("%s\n", argv[index]);
        }  
    }
    return EXIT_SUCCESS;
}